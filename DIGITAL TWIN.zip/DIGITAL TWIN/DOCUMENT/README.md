# 📍 2D Digital Twin of Mushin, Lagos – Service Accessibility Mapping

## 🎯 Objective

This map project visualizes the **spatial accessibility of basic services** (toilets, water taps, and solar panels) in the Mushin area of Lagos, Nigeria, using a **2D Digital Twin approach**. It identifies **unserved buildings** — those located **beyond 100 meters** from any simulated service point — to support data-driven planning and inclusive urban development.

> ⚠️ **Disclaimer:**  
> The service point data (toilets, taps, and solar panels) used in this project are **not from real-world sensors or field mapping**.  
> They were **randomly simulated** to demonstrate the **feasibility and concept** of digital twin mapping in the context of this **Hackathon**.

## 🧰 Tools Used

- **ArcGIS Pro** – for spatial analysis, buffering, and service gap detection  
- **QGIS** *(optional alternative)* – for open-source GIS visualization and layer styling  
- **GeoJSON/Shapefiles** – for representing building footprints, service zones, and unserved areas  
- **Git & GitHub** – for collaboration, documentation, and open reuse  
- **(Optional Extensions)**: CesiumJS / Unity3D – for future expansion into 3D and interactive simulation environments  

## 📂 File Structure

```
digital-twin-mushin/
├── data/
│   ├── buildings.geojson
│   ├── buffer_merged.geojson
│   └── unserved_buildings.geojson
├── maps/
│   └── final_2d_service_gap_map.png
├── docs/
│   └── README.md
```

## 🤝 How to Contribute or Reuse

### 🔧 Contribute
- Replace the simulated data with **field-collected or sensor-integrated datasets**
- Add additional urban layers (e.g., drainage, roads, population grids)
- Help connect this concept to **real-time APIs or mobile data collection tools**

### 🔁 Reuse
- Use this framework to prototype **digital twin solutions** in other informal settlements
- Integrate it into smart sanitation or off-grid infrastructure planning
- Adapt it for urban resilience, SDG monitoring, or public service allocation projects

## 🙌 Acknowledgments

This digital twin prototype was developed as part of a **Hackathon challenge** focused on using spatial data and technology for inclusive urban planning in African communities.

## 📫 Contact

Have questions, feedback, or want to collaborate?

📧 digitaltwin.team@email.com  
🌍 https://github.com/your-hackathon-team